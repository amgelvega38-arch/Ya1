# Mantenimiento global y actualización visual EL_07

## Cambios del cliente iOS
- El estado de mantenimiento ya no se guarda en `@AppStorage`; se consulta al servidor mediante `POST /api/public/maintenance`.
- El administrador autenticado (`role == admin`) no ve el bloqueo.
- Los usuarios normales reciben el estado del servidor al iniciar sesión y durante la revalidación periódica (cada 30 segundos).
- La opción de ajustes solo permite cambiar el estado cuando la sesión actual tiene rol `admin`.
- Se eliminaron las credenciales `07 / Xitado7` incrustadas en `SettingsView.swift`.
- Los fondos `BlindfoldAngelBackground` y `SettingsSonicBackground` se sustituyeron por la imagen adjunta.
- El nombre visible de la app se cambió a `07`.

## Contrato requerido en el servidor
El cliente envía:
`POST /api/public/maintenance`
```json
{"key":"KEY_DEL_USUARIO","device_id":"ID_DEL_DISPOSITIVO"}
```
Para cambiar el estado, el administrador envía además:
```json
{"key":"KEY_ADMIN","device_id":"ID_DEL_DISPOSITIVO","enabled":true}
```
Respuesta:
```json
{"ok":true,"enabled":true}
```

La carpeta `cloudflare/` incluye una implementación D1 de este endpoint y una tabla `app_settings`. Para usarla:
1. Ejecuta `wrangler d1 execute <BASE_DE_DATOS> --remote --file=schema.sql`.
2. Configura `ADMIN_KEY` como secreto del Worker.
3. Despliega el Worker.
4. Integra/despliega también las rutas de activación y catálogo que usa actualmente la app, o adapta la app para que todas sus rutas usen el Worker. El ZIP original apunta a una API Lovable y esa API no incluye aquí su código fuente.
5. Configura `PantherAPIBaseURL` con la URL HTTPS del servidor que realmente implemente todas las rutas.

**Importante:** el ZIP no puede activar por sí solo un endpoint remoto. Mientras el servidor publicado no implemente `/api/public/maintenance`, el cliente no podrá sincronizar el estado entre teléfonos. La implementación de Cloudflare incluida no está desplegada ni probada contra una cuenta real.

## Seguridad y límites
No existe una garantía honesta de “100% de seguridad”. Se quitó la contraseña fija del cliente y el servidor debe validar la key, dispositivo y rol administrador en cada cambio. Usa HTTPS, un secreto fuerte guardado como secreto del proveedor (nunca en el ZIP), protección contra intentos repetidos, auditoría y copias de seguridad. La app no puede impedir que alguien manipule un dispositivo con jailbreak o una compilación modificada.

## IPA
Este paquete contiene el proyecto fuente y los recursos. No contiene una IPA firmada. Para obtenerla hay que compilar en Xcode en macOS, configurar el servidor real y firmar con el certificado/perfil correspondiente. No se afirma que haya sido compilada ni probada en un iPhone.
