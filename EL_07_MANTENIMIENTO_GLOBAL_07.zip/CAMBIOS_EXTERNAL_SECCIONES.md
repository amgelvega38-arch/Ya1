# Cambios del menú External

- Se eliminó la sección TEXTURA/TEXTURAS y su paquete asociado.
- Se mantienen las secciones AIMBOT y HOLO ARMA.
- HOLO ARMA muestra dos controles funcionales: HOLO ARM RAINBOW (paquete Holograma Rtx.3105) y HOLO ARM AZUL (paquete Azul.3105 suministrado).
- Cada control consulta el recibo del paquete, aplica el patch y permite restaurarlo desde el mismo botón.
