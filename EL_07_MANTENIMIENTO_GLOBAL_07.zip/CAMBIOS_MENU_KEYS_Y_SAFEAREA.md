# Cambios de menú, keys y Dynamic Island

- El primer botón del menú AIMBOT muestra ahora `PECHO ALTO + CUELLO AVATAR`.
  Internamente sigue buscando el paquete existente `Pecho Avatar.3105`, por lo que no exige
  renombrar el archivo del paquete.
- El encabezado del menú Patch reserva un espacio superior de 58 pt (o el inset seguro si
  fuera mayor), para bajar el icono y evitar que quede debajo de la Dynamic Island.
- La app traduce los códigos del backend para key usada en otro dispositivo, key baneada y
  límite máximo de dispositivos. Consulta `MENSAJES_KEYS_API.md` para el contrato.
